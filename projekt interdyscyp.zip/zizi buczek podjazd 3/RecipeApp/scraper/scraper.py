import requests
from bs4 import BeautifulSoup

def search_recipes(query):
    ingredients = query.split()
    return scrape_recipes(ingredients)

def scrape_recipes(ingredients):
    search_query = '%20'.join(ingredients)
    url = f"https://www.kwestiasmaku.com/szukaj?search_api_views_fulltext={search_query}"
    response = requests.get(url)

    if response.status_code != 200:
        print(f"Failed to retrieve page: {response.status_code}")
        return []

    soup = BeautifulSoup(response.content, 'html.parser')
    recipes = []

    for item in soup.find_all('h2'):
        link_element = item.find('a')
        if link_element:
            title = link_element.get_text().strip()
            link = link_element['href']
            recipes.append({
                'title': title,
                'link': link.strip()
            })

    base_url = "https://www.kwestiasmaku.com"
    for recipe in recipes:
        recipe['link'] = base_url + recipe['link']

    print(f"Found recipes: {recipes}")
    return recipes

def get_full_recipe(recipe_url):
    response = requests.get(recipe_url)
    soup = BeautifulSoup(response.text, 'html.parser')

    title = soup.select_one('h2 > a').text.strip()
    subtitle = soup.select_one('h2.field-name-field-podtytul').text.strip()
    image = soup.select_one('img.img-responsive')['src']
    

    ingredients = []
    for ingredient in soup.select('.field-name-field-skladniki li'):
        ingredients.append(ingredient.text.strip())

    instructions = []
    for instruction in soup.select('.field-name-field-instrukcje li'):
        instructions.append(instruction.text.strip())

    return {
        'title': title,
        'subtitle': subtitle,
        'image': image,
        'ingredients': ingredients,
        'instructions': instructions
    }

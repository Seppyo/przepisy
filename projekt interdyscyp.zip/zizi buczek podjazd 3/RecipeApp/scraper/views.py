from django.shortcuts import render

# Create your views here.
import requests
from bs4 import BeautifulSoup
from django.http import JsonResponse
from django.http import HttpResponse
from django.shortcuts import render
from .forms import SearchForm
from .scraper import search_recipes

def home(request):
    return render(request, 'scraper/home.html')

def search(request):
    query = request.GET.get('query', '')
    recipes = []
    if query:
        recipes = search_recipes(query)
    return render(request, 'scraper/home.html', {'recipes': recipes, 'query': query})

def get_recipes(request):
    ingredients = requests.GET.get('ingredients')
    if not ingredients:
        return JsonResponse({'error': 'brak składników'}, status=400)
    
    url = f"strona"
    response = requests.get(url)

    if response.status_code!= 200:
        return JsonResponse({'error': 'nie udalo sie pobrac danych z zewnetrznej strony'}, status = 500)
    
    soup = BeautifulSoup(response.content, 'html.parser')
    recipes = []

    for recipe in soup.select('.recipe-card'):
        title = recipe.select_one('.title').get_text(strip=True)
        link = recipe.select_one('a')['href']
        description = recipe.select_one('.description').get_text(strip=True)
        recipes.append({
            "title": title,
            "link": link,
            "description": description,
        })

    return JsonResponse({"recipes": recipes})
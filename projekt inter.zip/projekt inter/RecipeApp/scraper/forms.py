from django import forms

class SearchForm(forms.Form):
    query = forms.CharField(label='Szukaj składników', max_length=100)

